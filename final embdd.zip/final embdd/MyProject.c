int t1;
int t2;
unsigned int voltage;
unsigned char Hi_Lo_flag;
unsigned int angle;

int turning_pwm = 4;
int turning_time_delay = 5000;


void interrupt();
void stop_moving();
void move_left();
void move_right();
void move_forward();
void move_backwards();
void pump_ON();
void pump_OFF();
void position();
void check_and_extinguish_fire();
void check_right();
void check_left();
void check_front();
void mymsDelay(int x);

void ATD_init_A0();
unsigned int ATD_read_A0();



void main() {
     TRISC = 0x00;
     TRISD = 0b01000000;
     TRISB = 0b11111101;
     TRISA = 0x01;

     PORTD = 0x00;
     PORTC = 0x00;
     PORTB = PORTB & 0b11111101;

   OPTION_REG= 0x87;//Use internal clock Fosc/4 with a prescaler of 256
   // Fosc=8MHz==> FTMR0 = 8MHz/4 = 2MHz, TMR0 will inc every 1/2MHz * prescaler
   //0.5uS* 256 = 128uS (per increment)
   TMR0=248;
   INTCON = 0b11100000; //GIE and , T0IE, peripheral interrupt



   CCP1CON=0x08;
   PIE1=PIE1|0x04;// Enable CCP1 interrupts
   CCPR1H=2000>>8;
   CCPR1L=2000;
   T1CON=0x01;
   TMR1H=0;
   TMR1L=0;
    Hi_Lo_flag = 1;
     ATD_init_A0();
     while(1){

              check_right();
              check_left();
              check_front();

              position();

              check_and_extinguish_fire();
 }
}






void interrupt(){
    if(INTCON & 0x04){// TMR0 Overflow interrupt, will get here every 1ms
       TMR0=248;
       t1++;
       t2++;
       INTCON = INTCON & 0xFB;//Clear T0IF
       }
if(PIR1&0x04){//CCP1 interrupt
   if(Hi_Lo_flag){ //high
     CCPR1H= angle >>8;
     CCPR1L= angle;
     Hi_Lo_flag=0;//next time low
     CCP1CON=0x09;//next time Falling edge
     TMR1H=0;
     TMR1L=0;
   }
   else{  //low
     CCPR1H= (40000 - angle) >>8;
     CCPR1L= (40000 - angle);
     CCP1CON=0x08; //next time rising edge
     Hi_Lo_flag=1; //next time High
     TMR1H=0;
     TMR1L=0;

   }
// clear CCP1 IF
PIR1=PIR1&0xFB;
 }
 if(PIR1&0x01){//TMR1 ovwerflow

   PIR1=PIR1&0xFE;
 }
}




void ATD_init_A0(){
ADCON0 = 0x41; // ATD ON, Dont go, channel 0, fosc/16
ADCON1 = 0xCE; // All channels are digital except A0 , 500 khz , right justified
}

unsigned int ATD_read_A0(){
ADCON0 = ADCON0 | 0x04; // GO
while(ADCON0 & 0x04);
return ((ADRESH<<8) | ADRESL);
}


void mymsDelay(int const x){
       t1=0;
       while(t1<x);

}

 void check_right(){
 // read port b4 : right flame sensor
if(PORTB & 0b00010000){
    t2 = 0;
    // read port b7 : front sensor until detects fire
    while(!(PORTB & 0b10000000)){

    // if it turns more than the turning_th stop (turning_th is time)
    if (t2 >= turning_time_delay) break;
    // move right
    move_right();

    }

// stop moving
stop_moving();
}
 }

void check_left(){
// read port b5 : left flame sensor
if (PORTB & 0b00100000){
     t2 = 0;
    // read port b7 : front sensor until detects fire
    while(!(PORTB & 0b10000000)){
      // move left
      if (t2 >= turning_time_delay) break;
      move_left();
      }
// stop moving
stop_moving();
}
}

void check_front(){
voltage = ATD_read_A0();


 while(voltage >= 150 && voltage <= 900){
voltage = ATD_read_A0();
 move_forward();
 }
 stop_moving();
}

void stop_moving(){
     PORTC = PORTC & 0b00001111;
}

void move_left(){
      PORTC = (PORTC & 0b00001111)| 0b01100000;
      mymsDelay(turning_pwm);
      stop_moving();
      mymsDelay(turning_pwm);

}

void move_right(){
   PORTC = (PORTC & 0b00001111) | 0b10010000;

      mymsDelay(turning_pwm);
      stop_moving();
      mymsDelay(turning_pwm);

}

void move_forward(){
     PORTC = (PORTC & 0b00001111)| 0b10100000;

     mymsDelay(3);
     stop_moving();
     mymsDelay(3);

}

void move_backwards(){
     PORTC = (PORTC & 0b00001111)| 0b01010000;

     mymsDelay(3);
     stop_moving();
     mymsDelay(3);
}

void pump_ON(){
        PORTB = PORTB | 0b00000010;
}

void pump_OFF(){
        PORTB = PORTB & 0b11111101;
}

void position(){
     voltage = ATD_read_A0();
     while(voltage < 150){
     move_backwards();
     voltage = ATD_read_A0();
}
stop_moving();
}

void check_and_extinguish_fire(){

//pump on while there is fire:
 voltage = ATD_read_A0();
 while (PORTB & 0b10000000)
 {     //check if fire is too close or fire is too far (we check if its too far because
 //we read the digital signal from the front flame sensor so as not to pump water from too far distance)
       if(voltage < 150 || voltage > 900) break;
       pump_ON();
       // servo ON:
       angle=3500;
       mymsDelay(1500);
       angle=1000;
       mymsDelay(1500);
 }
pump_OFF();
// adjust position of servo
angle =  2250;
}